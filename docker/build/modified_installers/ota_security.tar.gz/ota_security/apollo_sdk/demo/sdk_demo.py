#!/usr/bin/python
############################################################################
#
# CopyRight @ baidu.com 2017
#
#############################################################################
"""
demo for using secure upgrade SDK python API

Authors: niufan
Date: 2017/12/17
"""
from secure_upgrade_export import init_secure_upgrade
from secure_upgrade_export import sec_upgrade_get_package
from secure_upgrade_export import sec_upgrade_get_device_token
from secure_upgrade_export import sec_upgrade_get_authorization_token
from secure_upgrade_export import sec_upgrade_verify_package

"""
   you should set root_cofig_path and test_path properly
"""
test_path = "/home/caros/secure_upgrade/test/"
root_config_path = "/home/caros/secure_upgrade/config/secure_config.json"
returnCode = init_secure_upgrade(root_config_path)
print 'init secure upgrade result = ', returnCode

returnCode = sec_upgrade_get_package(test_path + "test.tgz", 
                                     test_path + "test_secure.tgz", 
                                     test_path + "package_token")
print 'get secure package result = ', returnCode

returnCode = sec_upgrade_get_device_token()
if returnCode[0] == True:
    print 'get device token successfully!'
else:
    print 'get device token failed!'

device_token = returnCode[1]

returnCode = sec_upgrade_get_authorization_token(test_path + "package_token",
                                                     device_token)
if returnCode[0] == True:
    print 'get auth token successfully!'
else:
    print 'get auth token failed!'

auth_token = returnCode[1]

returnCode = sec_upgrade_verify_package(auth_token, 
                                        test_path + "test_secure.tgz", 
                                        test_path + "vmware_orig.tgz")
if returnCode == True:
    print 'verify package  successfully!'
else:
    print 'verify package failed!!!'
