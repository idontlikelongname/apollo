/*
 * secure_upgrade_export.h
 *
 *  Created on: May 10, 2017
 *  Author: niufan@baidu.com
 */
#ifndef BAIDU_ADU_DATASECURITY_UPGRADE_SECURE_UPGRADE_EXPORT_H
#define BAIDU_ADU_DATASECURITY_UPGRADE_SECURE_UPGRADE_EXPORT_H

#include <stdio.h>
#include <string.h>

extern "C" {
namespace secure_upgrade {
//use config file to replace this
    bool init_secure_upgrade(const char* root_config_path);
    int sec_upgrade_get_device_token(unsigned char ** device_token_buffer,
                                 unsigned int * device_token_buffer_len);
    int sec_upgrade_get_package(const char* original_package_path,
                            const char* secure_package_path,
                            const char* package_token_path);
    int sec_upgrade_verify_package(unsigned char * authorization_token_buffer,
                               unsigned int authorization_token_buffer_len,
                               const char* secure_package_path,
                               const char* original_package_path);
    int sec_upgrade_get_authorization_token(const char * package_token_path,
                                        unsigned char * device_token_buffer,
                                        unsigned int  device_token_buffer_len,
                                        unsigned char ** authorization_token_buffer,
                                        unsigned int  * authorization_token_buffer_len);
} /* namespace carsec */

}
#endif /* RULES_H_ */

