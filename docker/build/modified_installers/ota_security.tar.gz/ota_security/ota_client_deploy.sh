#!/bin/bash

set -e
if [ "$#" -lt "1" ];then
        echo "you must enter current user acount name!!!!!!!!!!"
	exit
fi
o_base_dir=$(pwd)
cd $o_base_dir/release
echo "please log on root account!"
cd $(dirname $0)

base_dir=$(pwd)
echo $base_dir
sudo mkdir -p /home/caros/secure_upgrade/
sudo mkdir -p /home/caros/secure_upgrade/config
sudo mkdir -p /home/caros/secure_upgrade/python
sudo mkdir -p /home/caros/secure_upgrade/certificate
sudo mkdir -p /home/caros/secure_upgrade/key

sudo cp -rf $base_dir/resources/certificate/client/* /home/caros/secure_upgrade/certificate
sudo cp -rf $base_dir/resources/key/client/* /home/caros/secure_upgrade/key
sudo cp -rf $base_dir/resources/test /home/caros/secure_upgrade/

sudo chown root:root -R /home/caros/secure_upgrade/certificate
sudo chmod 755 -R /home/caros/secure_upgrade/certificate
sudo cp -f $base_dir/config/secure_config_client.json /home/caros/secure_upgrade/config/secure_config.json

sudo mkdir -p /home/caros/secure_upgrade/depend_lib
sudo cp -f $base_dir/lib*.so* /home/caros/secure_upgrade/depend_lib 
sudo cp -rf $base_dir/secure_upgrade_export.py /home/caros/secure_upgrade/python

chown -R $1:$1 /home/caros/secure_upgrade
echo "Sucess!"
