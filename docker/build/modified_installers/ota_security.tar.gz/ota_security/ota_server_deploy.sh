#!/bin/bash

set -e
if [ "$#" -lt "1" ];then
        echo "you must enter current user acount name!!!!!!!!!!"
	exit
fi
o_base_dir=$(pwd)
cd $o_base_dir/release
echo "please log on root account!"
cd $(dirname $0)

base_dir=$(pwd)
echo $base_dir
mkdir -p /home/caros/secure_upgrade/
mkdir -p /home/caros/secure_upgrade/config
mkdir -p /home/caros/secure_upgrade/python
mkdir -p /home/caros/secure_upgrade/certificate
mkdir -p /home/caros/secure_upgrade/key

cp -rf $base_dir/resources/certificate/server/* /home/caros/secure_upgrade/certificate
cp -rf $base_dir/resources/key/server/* /home/caros/secure_upgrade/key
cp -rf $base_dir/resources/test /home/caros/secure_upgrade/

chown root:root -R /home/caros/secure_upgrade/certificate
chmod 755 -R /home/caros/secure_upgrade/certificate
cp -f $base_dir/config/secure_config_server.json /home/caros/secure_upgrade/config/secure_config.json

mkdir -p /home/caros/secure_upgrade/depend_lib
cp -f $base_dir/lib*.so* /home/caros/secure_upgrade/depend_lib 
cp -rf $base_dir/secure_upgrade_export.py /home/caros/secure_upgrade/python

chown -R $1:$1 /home/caros/secure_upgrade
echo "Sucess!"
