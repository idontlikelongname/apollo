#!/usr/bin/python
############################################################################
#
# CopyRight @ baidu.com 2017
#
#############################################################################
"""
export interface for secure upgrade

Authors: niufan
Date: 2017/11/30
"""
import os
import sys
import multiprocessing

default_path = ':/home/caros/secure_upgrade/depend_lib/'
env = os.environ.get('LD_LIBRARY_PATH')
if env is None:
    sys.path.append(default_path)
else:
    env = env + default_path
    envlist=env.split(':')
    for each in envlist:
        sys.path.append(each)

import libsecure_upgrade_py as lib

def init_secure_upgrade(root_config_path):
    """
    init secure_upgrade module.
    return value:
    True: init successfully
    FalseL init failed
    """
    result = lib.init_secure_upgrade_export(root_config_path)
    if result == 1:
        return True
    else:
        return False

def sec_upgrade_get_package(original_package_path,
                            secure_package_path,
                            package_token_path):
    """
    secure upgrade module generate secure upgrade package and package token.
    return value:
    original_package_path :  unprotected upgrade package that server generate
    secure_package_path   :  secure package that secure module generate
    package_token_path    :  token for the secure package
    """
    result = lib.sec_upgrade_get_package_export(original_package_path,
                                                secure_package_path,
                                                package_token_path)
    if result == 0:
        return True
    else:
        return False

def sec_upgrade_get_device_token():
    """
    secure upgrade module generate device token in the device end.
    return value:
    (returncode, device_token)    :  returncode: True , generate device
                                                 token successfully
                                                 False, generate device
                                                 token failed
                                     device_token: devide_token buffer 
                                     for upload to server
    """
    result = lib.sec_upgrade_get_device_token_export()
    if result[0] == 0:
        return (True, result[1])
    else:
        return (False, result[1])

def sec_upgrade_get_authorization_token(package_token_path,
                                        device_token):
    """
    secure upgrade module generate auth token for upgrade.
    input value :   
                 package_token_path : token for every secure package
                 device_token       : device token buffer received from device
    return value:
                 authorization token buffer :  authorization token for 
                                               upgrade 
    """
    result = lib.sec_upgrade_get_authorization_token_export(package_token_path,
                                                            device_token)
    if result[0] == 0:
        return (True, result[1])
    else:
        return (False, result[1])

def sec_upgrade_verify_package(auth_token,
                               secure_package_path,
                               original_package_path):
    """
    secure upgrade module generate auth token for upgrade.
    input value :   
                 auth_token : token for authorizing the secure upgrade
                 secure_package_path  : secure package for verifing in device end
                 original_package_path  : original package for installing
    return value:
                 True :  verify package successfully 
                 False:  verify package failed 
    """
    result = lib.sec_upgrade_verify_package_export(auth_token,
                                                   secure_package_path,
                                                   original_package_path)
    if result == 0:
        return True
    else:
        return False

if __name__ == '__main__':
    print "os.getcwd()=%s" % os.getcwd()
    current_path = os.getcwd()
    test_path = "/home/caros/secure_upgrade/test/"
    root_config_path = "/home/caros/secure_upgrade/config/secure_config.json"
    returnCode = init_secure_upgrade(root_config_path)
    print 'init secure upgrade result = ', returnCode

    returnCode = sec_upgrade_get_package(test_path + "test.tgz", 
                                         test_path + "test_secure.tgz", 
                                         test_path + "package_token")
    print 'get secure package result = ', returnCode

    returnCode = sec_upgrade_get_device_token()
    if returnCode[0] == True:
        print 'get device token successfully!'
    else:
        print 'get device token failed!'

    device_token = returnCode[1]

    returnCode = sec_upgrade_get_authorization_token(test_path + "package_token",
                                                     device_token)
    if returnCode[0] == True:
        print 'get auth token successfully!'
    else:
        print 'get auth token failed!'

    auth_token = returnCode[1]

    returnCode = sec_upgrade_verify_package(auth_token, 
                                            test_path + "test_secure.tgz", 
                                            test_path + "vmware_orig.tgz")
    if returnCode == True:
        print 'verify package  successfully!'
    else:
        print 'verify package failed!!!'
